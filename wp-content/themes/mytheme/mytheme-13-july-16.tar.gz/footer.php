<footer>
<h2 class="screen-reader-text">Footer Information:</h2>
<aside class="general left two-thirds">
<h3>Socialize</h3>
<ul class="grid4up">
    <li><a href="#" class="soc facebook">facebook</a></li>
    <li><a href="#" class="soc twitter">twitter</a></li>
    <li><a href="#" class="soc rss">rss</a></li>
    <li><a href="#" class="soc google">gmail</a></li>
</ul>

<div class="push"></div>
<h3>About us</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
</aside>

<aside class="navigate right third">
<h3>Navigate</h3>
<ul>
    <li><a href="#" target="" title="">title to link01</a> </li>
    <li><a href="#" target="" title="">another link02</a></li>
    <li><a href="#" target="" title="">a different title: link03</a></li>
    <li><a href="#" target="" title="">yet another link04</a></li>
</ul>
</aside>

<div class="push"></div>

</footer>
</div><!--//#across-->
<?php wp_footer(); ?>
</body>
</html>
